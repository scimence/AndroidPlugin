/** Automatically generated file. DO NOT MODIFY */
package com.ltsdk.tool.showtext;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}