package sci.apk.plugin;

import android.app.Activity;
import android.os.Bundle;

/** 插件EmptyActivity调用示例 */
public class EntryDemo extends Activity
{	
	// 已插件方式启动当前应用中的插件Activity
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		
		EmptyActivity.Show(this, "com.pluginDemo.showdebug.MainActivity");	// 通过EmptyActivity执行MainActivity功能
		this.finish();
	}
	
	// 载入apk包插件并启动
//	public void onCreate(Bundle savedInstanceState)
//	{
//		super.onCreate(savedInstanceState);
//		
//		String apkPath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/backups/apps/ShowLogCat_sign.apk";
//		EmptyActivity.ShowPlugin(this, apkPath);								// 启动插件
////		EmptyActivity.Show(this, apkPath, "com.ltsdk.showdebug.MainActivity");	// 通过EmptyActivity执行插件apk指定Activity的功能
//		
//		this.finish();	// 结束当前Activity
//	}
	
	
}
