
package com.app.empty_shell;

import java.io.File;

import sci.apk.plugin.EmptyActivity;
import sci.tool.web.DownloadTool;
import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Toast;


public class MainActivity extends Activity
{
	String pluginApk = "";
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.empty_activity_main);
		
		pluginApk = Environment.getExternalStorageDirectory().getAbsolutePath() + "/backups/apps/AndroidPlugin_plugin1.apk";
		DownloadPluginTo(pluginApk);
	}
	
	// 启动插件
	public void OpenPlugin(View view)
	{
		if (!new File(pluginApk).exists())
		{
			Toast.makeText(this, "插件不存在！", Toast.LENGTH_SHORT).show();
		}
		else
		{
			EmptyActivity.ShowPlugin(this, pluginApk);								// 启动插件
			// EmptyActivity.Show(this, apkPath, "com.ltsdk.showdebug.MainActivity"); // 通过EmptyActivity执行插件apk指定Activity的功能
		}
	}
	
	// 若插件不存在，则自动下载
	public void DownloadPluginTo(String filePath)
	{
		if (!new File(filePath).exists())
		{
			String Url = "https://raw.githubusercontent.com/scimence/AndroidPlugin/master/apk/AndroidPlugin_plugin1.apk";
			DownloadTool.DownloadFile(Url, filePath);
		}
	}
	
}
