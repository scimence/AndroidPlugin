
package sci.apk.pluginBase;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;


/** 
 * BaseActivity，继承Activity中的所有功能函数，作为功能、变量转接层，封装子Activity中的所有功能。 
 * 在emptyActivity通过反射调用BaseActivity中的功能函数，实现代理显示和执行功能。
 * 
 * 用法：继承BaseActivity 
 *  */
public class BaseActivity extends Activity
{
	/** 当前Activity的所有功能和逻辑，将在emptyActivity中执行和展示 */
	private Activity emptyActivity;
	
	/** 设置当前Activity的执行Context，当前Activity仅用于获取功能逻辑，在emptyActivity的上下文环境中执行 */
	public void SetContext(Activity context)
	{
		emptyActivity = context;
		super.attachBaseContext(context);	// 设置当前Activity的上下文环境
	}
	
	boolean isPlugin = true;
	
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// 若为（插件apk单独运行），则需执行onCreate()，则使用当前Activity执行逻辑
		if (!isPlugin)
			super.onCreate(savedInstanceState);
		
		// 若为（插件apk调用），则需在执行Context中执行
		// emptyActivity中已实现该接口，故此处留空。emptyActivity中通过plugin.onCreate(extras); 调用子类的初始化功能
		else
		;
	}
	
	@Override
	public View findViewById(int id)
	{
		if (!isPlugin)
			return super.findViewById(id);
		else return emptyActivity.findViewById(id);
	}
	
	@Override
	public void finish()
	{
		if (!isPlugin)
			super.finish();
		else emptyActivity.finish();
	}
	
	public void onStart()
	{
		if (!isPlugin) super.onStart();
	}
	
	public void onResume()
	{
		if (!isPlugin) super.onResume();
	}
	
	@Override
	public void onRestart()
	{
		if (!isPlugin) super.onRestart();
	}
	
	public void onPause()
	{
		if (!isPlugin) super.onPause();
	}
	
	public void onStop()
	{
		if (!isPlugin) super.onStop();
	}
	
	public void onDestroy()
	{
		if (!isPlugin) super.onDestroy();
	}
	
	public void onSaveInstanceState(Bundle outState)
	{
		if (!isPlugin) super.onSaveInstanceState(outState);
	}
	
	public boolean onTouchEvent(MotionEvent event)
	{
		return false;
	}
	
	public void onBackPressed()
	{
		if (!isPlugin)
			super.onBackPressed();
		else emptyActivity.onBackPressed();
	}
	
	@Override
	public void startActivity(Intent intent)
	{
		if (!isPlugin)
			super.startActivity(intent);
		else emptyActivity.startActivity(intent);
	}
	
	// ------
	
	public Intent getIntent()
	{
		if (!isPlugin)
			return super.getIntent();
		else return emptyActivity.getIntent();
	}
	
	@Override
	public LayoutInflater getLayoutInflater()
	{
		if (!isPlugin)
			return super.getLayoutInflater();
		else return emptyActivity.getLayoutInflater();
	}
	
	public Context getApplicationContext()
	{
		if (!isPlugin)
			return super.getApplicationContext();
		else return emptyActivity.getApplicationContext();	// 获取context, context为emptyActivity中的值
	}
	
	@Override
	public Window getWindow()
	{
		if (!isPlugin)
			return super.getWindow();
		else return emptyActivity.getWindow();
	}
	
	@Override
	public ClassLoader getClassLoader()
	{
		if (!isPlugin)
			return super.getClassLoader();
		else return emptyActivity.getClassLoader();
	}
	
	@Override
	public WindowManager getWindowManager()
	{
		if (!isPlugin)
			return super.getWindowManager();
		else return emptyActivity.getWindowManager();
	}
	
	@Override
	public ApplicationInfo getApplicationInfo()
	{
		if (!isPlugin)
			return super.getApplicationInfo();
		else return emptyActivity.getApplicationInfo();
	}
	
	public String getPackageName()
	{
		if (!isPlugin)
			return super.getPackageName();
		else return emptyActivity.getPackageName();
	}
	
	public Resources.Theme getTheme()
	{
		if(!isPlugin) return super.getTheme();
		else return emptyActivity.getTheme();
	}
	
	public Resources getResources()
	{
		if (!isPlugin) return super.getResources();
		else return emptyActivity.getResources();
	}
	
	public Object getSystemService(String name)
	{
		if (emptyActivity == null)	// 若当前函数执行时context为null，则为apk插件调试生成逻辑（非插件调用）
		{
			isPlugin = false;
		}
		
		if (!isPlugin)
			return super.getSystemService(name);
		else return emptyActivity.getSystemService(name);
	}
	
	// ------
	
	@Override
	public void setContentView(int layoutResID)
	{
		if (!isPlugin)
			super.setContentView(layoutResID);
		else emptyActivity.setContentView(layoutResID);
	}
	
	@Override
	public void setContentView(View view)
	{
		if (!isPlugin)
			super.setContentView(view);
		else emptyActivity.setContentView(view);			// 在代理Activity中展示view
	}
	
	@Override
	public void setContentView(View view, ViewGroup.LayoutParams params)
	{
		if (!isPlugin)
			super.setContentView(view, params);
		else emptyActivity.setContentView(view, params); // 在代理Activity中展示
	}
	
	public void setTitle(CharSequence title)
	{
		if (!isPlugin)
			super.setTitle(title);
		else emptyActivity.setTitle(title);
	}
	
}
