
package sci.apk.plugin;

import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;

/** 
 * 代理Activity,封装Activity的生命周期函数，为一个空壳。通过参数，载入并创建对应的插件Activity对象，展示对应功能。
 * 
 * 通过EmptyActivity展示BaseActivity子类Activity(AndroidManifest.xml中仅需声明EmptyActivity即可), 
 * 
 * 示例：
 * EmptyActivity.Start(context, "com.ltsdk.showdebug.MainActivity");
 **/
public class EmptyActivity extends Activity
{
	static final String ARG_KEY = "Plugin_ActivityName";
	static final String ARG_APK = "Plugin_ApkPath";
	
	/** 通过EmptyActivity展示targetActivity，要求targetActivity必须为BaseActivity的子类 */
	public static void Show(Context context, String targetActivityName)
	{
		Show(context, "", targetActivityName);
	}
	
	/** 通过EmptyActivity展示targetActivity，要求targetActivity必须为BaseActivity的子类，targetActivity在插件apk中  */
	public static void Show(Context context, String apkPath, String targetActivityName)
	{
		if(apkPath == null) apkPath = "";
		if(targetActivityName == null) targetActivityName = "";
		
		Intent intent = new Intent(context, EmptyActivity.class);
		intent.putExtra(ARG_APK, apkPath );					// 传参：插件Apk文件路径
		intent.putExtra(ARG_KEY, targetActivityName );		// 传参：Activity类名称，在EmptyActivity中展示和执行
		context.startActivity(intent);
	}
	
	/** 通过EmptyActivity展示,插件apk的首个Activity */
	public static void ShowPlugin(Context context, String apkPath)
	{
		Show(context, apkPath, "");
	}
	
	//---------
	
	String apkPath="";
	ApkPlugin apk = null;
	Plugin plugin;
	
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		
		apkPath = getIntent().getStringExtra(ARG_APK);				// 获取apk文件路径
		String className = getIntent().getStringExtra(ARG_KEY); 	// 获取插件Activity名称
		
		if(apkPath.equals(""))	// 从当前应用中载入类
		{
			plugin = new Plugin(this, className);			// 从BaseActivity子类创建plugin，执行具体插件Activity功能逻辑
		}
		else					// 从插件apk中载入类
		{
			apk = ApkPlugin.Get(this, apkPath);				// 获取apk插件
			if(className.equals(""))className = apk.Activitys()[0].name;	// 若未指定要启动的Activity，则启动首个Activity
			
			Class<?> classType = apk.getClass(className);	// 获取类类型
			plugin = new Plugin(this, classType);			
		}
		
		
		Bundle extras = getIntent().getExtras();
		extras.remove(ARG_APK);
		extras.remove(ARG_KEY);
		plugin.onCreate(extras);					// 调用插件Activity初始化逻辑，对当前Activity进行初始化
		
		Adapt_LayoutView_Onclick(this);				// 改写布局View中的Onclick
	}
	
	@Override
	public void startActivity(Intent intent)
	{
		Intent newIntent = new Intent(this, EmptyActivity.class);
		newIntent.putExtras(intent.getExtras());							// BaseActivity子类启动参数
		
		newIntent.putExtra(ARG_APK, apkPath);
		newIntent.putExtra(ARG_KEY, intent.getComponent().getClassName());	// EmptyActivity将代理显示的类
		
		super.startActivity(newIntent);
	}
	
	/** 载入插件中的Resources资源 */
	@Override
	public Resources getResources()
	{
		if(!apkPath.equals("")) return apk.resources;
		else return super.getResources();
	}
	
	@Override
	public void onStart()
	{
		plugin.onStart();
		super.onStart();
	}
	
	@Override
	public void onResume()
	{
		plugin.onResume();
		super.onResume();
	}
	
	@Override
	public void onRestart()
	{
		plugin.onRestart();
		super.onRestart();
	}
	
	@Override
	public void onDestroy()
	{
		plugin.onDestroy();
		super.onDestroy();
	}
	
	@Override
	public void onStop()
	{
		plugin.onStop();
		super.onStop();
	}
	
	@Override
	public void onPause()
	{
		plugin.onPause();
		super.onPause();
	}
	
	@Override
	public void setContentView(int layoutResID)
	{
		super.setContentView(layoutResID);
	}

	@Override
	public void setContentView(View view)
	{
		super.setContentView(view);
	}
	
	@Override
	public void setContentView(View view, ViewGroup.LayoutParams params)
	{
		super.setContentView(view, params);
	}
	
	/**  映射res/layout布局文件中View对应的Onclick属性对应函数方法(如：android:onClick="button1_Click")，至插件Activity下的对应函数。
	 * （解析设置布局后，View中设定的OnClick函数名，新建OnclickListener指向插件Activity中的对应函数） */
	private void Adapt_LayoutView_Onclick(Activity activity)
	{
		List<View> views = ViewTool.Childs(activity);
		for(View view : views)
		{
			final String name = ReflectTool.get_onClickName(view);	// 获取反射方法名
			if(!name.equals(""))
			{
				view.setOnClickListener(new OnClickListener()
				{
					@Override
					public void onClick(View v)
					{
						plugin.ClickView(name, v);		// 调用对应点击事件
					}
				});
			}
		}
	}
	
}
