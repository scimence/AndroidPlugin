
package sci.apk.plugin;

import java.util.HashMap;
import java.util.Map;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.content.res.Resources;
import dalvik.system.DexClassLoader;


/** ApkPlugin.java: 用于载入功能apk中的相关资源，并打开指定的Activity ----- 2019-3-8 下午4:35:59 scimence */
public class ApkPlugin
{
	static Map<String, ApkPlugin> apkCache = new HashMap<String, ApkPlugin>();
	
	/** 获取指定路径下的apk插件包，载入相关信息 */
	public static ApkPlugin Get(Context appContext, String apkPath)
	{
		if(!apkCache.containsKey(apkPath)) 
		{
			ApkPlugin apk = new ApkPlugin(appContext, apkPath);
			apkCache.put(apkPath, apk);
		}
		return apkCache.get(apkPath);
	}
	
	/** 移除指定的插件apk缓存信息 */
	public static void Remove(String apkPath)
	{
		if(apkCache.containsKey(apkPath)) apkCache.remove(apkPath);
	}
	
	/** 清空插件apk信息 */
	public static void Clear(String apkPath)
	{
		apkCache.clear();
	}
	
	//-----------------------------------------
	
	String apkPath = "";
	public DexClassLoader dexClassLoader;
	public PackageInfo packageInfo;
	public Resources resources;
	
	private ApkPlugin(Context appContext, String apkPath)
	{
		this.apkPath = apkPath;
		
		loadApk(appContext, apkPath);
	}
	
	/** 载入插件apk */
	public void loadApk(Context appContext, String apkPath)
	{
		Context context = appContext.getApplicationContext();
		
		String dexDir = context.getDir("dex", Context.MODE_PRIVATE).getAbsolutePath();
		dexClassLoader = new DexClassLoader(apkPath, dexDir, null, context.getClassLoader());
		
		packageInfo = context.getPackageManager().getPackageArchiveInfo(apkPath, PackageManager.GET_ACTIVITIES);
		
		AssetManager assets = ReflectTool.getAssetManager(apkPath);
		resources = new Resources(assets, context.getResources().getDisplayMetrics(), context.getResources().getConfiguration());
	}
	
	/** 获取apk中的类，指定类名称className */
	public Class<?> getClass(String className)
	{
		Class<?> cls = null;
		try
		{
			cls = dexClassLoader.loadClass(className);
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
		if(cls == null) throw new IllegalStateException("Could not find class " + className + " in the apk file " + apkPath);
		
		return cls;
	}
	
	/** 获取插件apk中的Activity信息 */
	public ActivityInfo[] Activitys()
	{
		return packageInfo.activities;
	}
}
