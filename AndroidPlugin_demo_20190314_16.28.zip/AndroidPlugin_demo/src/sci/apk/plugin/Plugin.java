
package sci.apk.plugin;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;


public class Plugin
{
	Object classObj;
	
	/** 插件接口，创建BaseActivity子类对象。反射调用类中的相关接口并封装（供在EmptyActivity使用） */
	public Plugin(Activity emptyActivity, String className)
	{
		try
		{
			Class<?> classType = Class.forName(className);	// 获取类类型
			classObj = classType.newInstance();				// 创建类实例
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		
		SetContext(emptyActivity);	// 设置插件Activity的执行环境为emptyActivity
	}
	
	/** 插件接口，创建BaseActivity子类classType对象。反射调用类中的相关接口并封装（供在EmptyActivity使用） */
	public Plugin(Activity emptyActivity, Class<?> classType)
	{
		try
		{
			// Class<?> classType = Class.forName(className); // 获取类类型
			classObj = classType.newInstance();				// 创建类实例
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		
		SetContext(emptyActivity);	// 设置插件Activity的执行环境为emptyActivity
	}
	
	/** 设置插件Activity的执行Context */
	private void SetContext(Activity context)
	{
		CallMethod("SetContext", Activity.class, context);		// 反射调用函数方法SetContext(Activity context)
	}
	
	public void onCreate(Bundle saveInstance)
	{
		CallMethod("onCreate", Bundle.class, saveInstance);		// 反射调用函数方法onCreate(Bundle saveInstance)
	}
	
	public void onStart()
	{
		CallMethod("onStart");
	}
	
	public void onResume()
	{
		CallMethod("onResume");
	}
	
	public void onRestart()
	{
		CallMethod("onRestart");
	}
	
	public void onDestroy()
	{
		CallMethod("onDestroy");
	}
	
	public void onStop()
	{
		CallMethod("onStop");
	}
	
	public void onPause()
	{
		CallMethod("onPause");
	}
	
	/** 调用对应点击事件，反射调用指定的方法methodName(View view) */
	public void ClickView(String methodName, Object view)
	{
		CallMethod(methodName, View.class, view);
	}
	
	public Object CallMethod(String methodName)
	{
		return ReflectTool.CallMethod(classObj, methodName);
	}
	
	public Object CallMethod(String methodName, Class<?> argClass, Object argObj)
	{
		return ReflectTool.CallMethod(classObj, methodName, argClass, argObj);
	}
}
