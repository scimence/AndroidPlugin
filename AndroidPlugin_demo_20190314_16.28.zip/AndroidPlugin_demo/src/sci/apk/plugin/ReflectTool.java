
package sci.apk.plugin;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import android.content.res.AssetManager;
import android.os.Bundle;
import android.util.ArrayMap;
import android.view.View;

/** 反射，调用Object中的函数、获取Object中的指定变量 */
public class ReflectTool
{
	/** 反射调用，Obj对象的methodName()函数 */
	public static Object CallMethod(Object Obj, String methodName)
	{
		if(Obj==null) throw new NullPointerException("Obj == null");
		
		Object result = null;
		Method methodObj = null;
		Class<?> classType = null;
		try
		{
			classType = Obj.getClass();
			methodObj = classType.getMethod(methodName); 	// 获取类中的函数方法
			result = methodObj.invoke(Obj);					// 反射调用函数方法classObj.methodName()
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		if (methodObj == null) throw new IllegalStateException("Could not find a method " + methodName + "() in the class " + classType.getName());
		
		return result;
	}
	
	/** 反射调用函数methodName(argClass, argObj) */
	public static Object CallMethod(Object Obj, String methodName, Class<?> argClass, Object argObj)
	{
		if(Obj==null) throw new NullPointerException("Obj == null");
		
		Object result = null;
		Method methodObj = null;
		Class<?> classType = null;
		try
		{
			classType = Obj.getClass();
			methodObj = classType.getMethod(methodName, argClass); 	// 获取类中的函数方法
			result = methodObj.invoke(Obj, argObj);					// 反射调用函数方法classObj.methodName(argObj)
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		if (methodObj == null)
			throw new IllegalStateException("Could not find a method " + methodName + "(" + argClass.getSimpleName() + ") in the class " + classType.getName());
		
		return result;
	}
	
	/** 反射调用函数methodName(...argObj) */
	public static Object CallMethodX(Object Obj, String methodName, Object... argObj)
	{
		if(Obj==null) throw new NullPointerException("Obj == null");
		
		Object result = null;
		Method methodObj = null;
		Class<?> classType = null;
		
		Class<?>[] argClass = null;
		try
		{
			// 获取参数类型
			List<Class<?>> list = new ArrayList<Class<?>>();
			for (Object arg : argObj)
			{
				list.add(arg.getClass());
			}
			argClass = new Class<?>[list.size()];
			list.toArray(argClass);
			
			classType = Obj.getClass();
			methodObj = classType.getMethod(methodName, argClass); 	// 获取类中的函数方法
			result = methodObj.invoke(Obj, argObj);					// 反射调用函数方法classObj.methodName(argObj)
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		
		if (methodObj == null)
		{
			String argsType = "";
			for (Class<?> cls : argClass)
			{
				argsType += cls.getSimpleName() + ", ";
			}
			if (argsType.length() > 2) argsType = argsType.substring(0, argsType.length() - 2);
			
			throw new IllegalStateException("Could not find a method " + methodName + "(" + argsType + ") in the class " + classType.getName());
		}
		
		return result;
	}
	
	
	/** 反射获取obj的成员变量fieldName（成员变量名获取，可在调试时动态查看） */
	public static Object getSubField(Object obj, String fieldName)
	{
		if(obj==null) throw new NullPointerException("obj == null");
		
		Object subObj = null;
		try
		{
			if (obj != null)
			{
				Field field = obj.getClass().getDeclaredField(fieldName);	// 获取成员变量对应的Field方法
				field.setAccessible(true);	// 设置为可访问
				subObj = field.get(obj);	// 通过Field方法从Object中提取子变量
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		return subObj;
	}
	
	/** 反射获取obj的成员变量fieldName（成员变量名获取，可在调试时动态查看） */
	public static Object getSubField(Object obj, Class<?> cls, String fieldName)
	{
		if(obj==null) throw new NullPointerException("obj == null");
		Object subObj = null;
		try
		{
			if (obj != null)
			{
				Field field = cls.getDeclaredField(fieldName);	// 获取成员变量对应的Field方法
				field.setAccessible(true);	// 设置为可访问
				subObj = field.get(obj);	// 通过Field方法从Object中提取子变量
			}
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		return subObj;
	}
	
	/** 通过反射，获取View的在res/Layout布局中声明的onClick属性名称 */
	public static String get_onClickName(View view)
	{
		if(view==null) throw new NullPointerException("view == null");
		String Name = "";
		
		// 反射 View.mListenerInfo.mOnClickListener.val$handlerName
		try
		{
			Object mListenerInfo = getSubField(view, View.class, "mListenerInfo");
			Object mOnClickListener = getSubField(mListenerInfo, "mOnClickListener");
			Object handlerName = getSubField(mOnClickListener, "val$handlerName");
			Name = handlerName.toString();
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		
		return Name;
	}
	
	/** 获取apk包，对应的AssetManager */
	public static AssetManager getAssetManager(String apkPath)
	{
		AssetManager assets = null;
		try
		{
			assets = AssetManager.class.newInstance();		// 创建类实例
			CallMethodX(assets, "addAssetPath", apkPath);	// 添加apk路径至Asset资源路径
			
//			Method addAssetPath = AssetManager.class.getMethod("addAssetPath", String.class);
//			addAssetPath.invoke(assets, apkPath);
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return assets;
	}
	
//	public static ArrayMap<String, Object> GetMap(Bundle bundle)
//	{
//		ArrayMap<String, Object> map = null;
//		try
//		{
//			Object mMap = getSubField(bundle, "mMap");
//			map = (ArrayMap<String, Object>) mMap;
//		}
//		catch (Exception ex)
//		{
//			ex.printStackTrace();
//		}
//		return map;
//	}
	
}
